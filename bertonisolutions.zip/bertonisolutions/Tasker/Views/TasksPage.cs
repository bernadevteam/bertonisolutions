﻿using System;
namespace Tasker.Views
{
    public class TasksPage
    {
        public TasksPage()
        {
        }
    }
}
